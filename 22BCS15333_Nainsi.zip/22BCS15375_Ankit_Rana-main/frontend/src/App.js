
import React from 'react';
import CrisisManagement from './pages/CrisisManagement';

function App() {
    return (
        <div>
            <CrisisManagement />
        </div>
    );
}

export default App;
                