# Backend for Crisis Communication System
